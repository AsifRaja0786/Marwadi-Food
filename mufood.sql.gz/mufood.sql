-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 22, 2022 at 09:20 PM
-- Server version: 10.4.25-MariaDB
-- PHP Version: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mufood`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `adminname` varchar(89) NOT NULL,
  `email` varchar(89) NOT NULL,
  `password` varchar(89) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `adminname`, `email`, `password`) VALUES
(1, 'Asif Raja', 'mohammadasif.raja108126@marwadiuniversity.ac.in', 'root'),
(2, 'Niraj Giri', 'niraj@gmail.com', 'root');

-- --------------------------------------------------------

--
-- Table structure for table `chefs`
--

CREATE TABLE `chefs` (
  `id` int(11) NOT NULL,
  `name` varchar(89) NOT NULL,
  `post` varchar(89) NOT NULL,
  `img` varchar(89) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `chefs`
--

INSERT INTO `chefs` (`id`, `name`, `post`, `img`) VALUES
(1, 'MAMU', 'Head Chef', 'chefImg1.jpg'),
(2, 'SACHIT', 'Pizza Specialist', 'chefImg2.jpg'),
(3, 'Bikash', 'Baker', 'chefImg3.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `friday`
--

CREATE TABLE `friday` (
  `id` int(11) NOT NULL,
  `food` varchar(89) NOT NULL,
  `img` varchar(89) NOT NULL,
  `startTime` varchar(89) NOT NULL,
  `endTime` varchar(89) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `friday`
--

INSERT INTO `friday` (`id`, `food`, `img`, `startTime`, `endTime`) VALUES
(1, 'Brown Bread / Salad / Non-Veg', 'friday_breakfast.jpg', '7:00 AM', '9:30 AM'),
(2, 'Turnip / Cucumber / Green', 'friday_launch.jpg', '12:30 PM', '2:30 PM'),
(3, 'Tomato / Spices / Lemon', 'friday_snacks.jpg', '5:00 PM', '6:30 PM'),
(4, 'Pasta / cheese / Paneer', 'friday_dinner.jpg', '7:30 PM', '9:30 PM');

-- --------------------------------------------------------

--
-- Table structure for table `monday`
--

CREATE TABLE `monday` (
  `id` int(11) NOT NULL,
  `food` varchar(89) NOT NULL,
  `img` varchar(89) NOT NULL,
  `startTime` varchar(8) NOT NULL,
  `endTime` varchar(8) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `monday`
--

INSERT INTO `monday` (`id`, `food`, `img`, `startTime`, `endTime`) VALUES
(1, 'Brown Bread / Salad / Non-Veg', 'monday_breakfast.jpg', '7:00 AM', '9:30 AM'),
(2, 'Turnip / Cucumber / Green', 'monday_launch.jpg', '12:30 PM', '2:30 PM'),
(3, 'Tomato / Spices / Lemon', 'monday_snacks.jpg', '5:00 PM', '6:30 PM'),
(4, 'Pasta / cheese / Paneer', 'monday_dinner.jpg', '7:30 PM', '9:30 PM');

-- --------------------------------------------------------

--
-- Table structure for table `saturday`
--

CREATE TABLE `saturday` (
  `id` int(11) NOT NULL,
  `food` varchar(89) NOT NULL,
  `img` varchar(89) NOT NULL,
  `startTime` varchar(8) NOT NULL,
  `endTime` varchar(8) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `saturday`
--

INSERT INTO `saturday` (`id`, `food`, `img`, `startTime`, `endTime`) VALUES
(1, 'Brown Bread / Salad / Non-Veg', 'saturday_breakfast.jpg', '7:00 AM', '9:30 AM'),
(2, 'Turnip / Cucumber / Green', 'saturday_launch.jpg', '12:30 PM', '2:30 PM'),
(3, 'Tomato / Spices / Lemon', 'saturday_snacks.jpg', '5:00 PM', '6:30 PM'),
(4, 'Pasta / cheese / Paneer', 'saturday_dinner.jpg', '7:30 PM', '9:30 PM');

-- --------------------------------------------------------

--
-- Table structure for table `specialmenu`
--

CREATE TABLE `specialmenu` (
  `id` int(11) NOT NULL,
  `food` varchar(89) NOT NULL,
  `fullmenu` varchar(89) NOT NULL,
  `feedback` varchar(89) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `specialmenu`
--

INSERT INTO `specialmenu` (`id`, `food`, `fullmenu`, `feedback`) VALUES
(1, 'Gulab Jamun', 'White / Dark / Dairy Product', ''),
(2, 'Pizzaone', 'Mithai / Milk Sweets / Ghee', ''),
(3, 'Mutton Curry', 'Gravy / Fried / Biryani', ''),
(4, 'Salad', 'Salad / Buck Wheat / Carrots', ''),
(5, 'Ice Cream', 'Strawberry / Butter Scotch / Chocolate', ''),
(6, 'Pizza', 'Cheesy / Butter / Normal', ''),
(7, 'Omlets', 'Spicy / Non-Spicy / Normal', ''),
(8, 'Bread ', 'Brown Bread / Jmas / Honey', '');

-- --------------------------------------------------------

--
-- Table structure for table `sunday`
--

CREATE TABLE `sunday` (
  `id` int(11) NOT NULL,
  `food` varchar(89) NOT NULL,
  `img` varchar(89) NOT NULL,
  `startTime` varchar(8) NOT NULL,
  `endTime` varchar(8) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `sunday`
--

INSERT INTO `sunday` (`id`, `food`, `img`, `startTime`, `endTime`) VALUES
(1, 'Brown Bread / Salad / Non-Veg', 'sunday_breakfast.jpg', '7:00 AM', '9:30 AM'),
(2, 'Turnip / Cucumber / Green', 'sunday_launch.jpg', '12:30 PM', '2:30 PM'),
(3, 'Tomato / Spices / Lemon', 'sunday_snacks.jpg', '5:00 PM', '6:30 PM'),
(4, 'Pasta / cheese / Paneer', 'sunday_dinner.jpg', '7:30 PM', '9:30 PM');

-- --------------------------------------------------------

--
-- Table structure for table `thursday`
--

CREATE TABLE `thursday` (
  `id` int(11) NOT NULL,
  `food` varchar(89) NOT NULL,
  `img` varchar(89) NOT NULL,
  `startTime` varchar(8) NOT NULL,
  `endTime` varchar(8) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `thursday`
--

INSERT INTO `thursday` (`id`, `food`, `img`, `startTime`, `endTime`) VALUES
(1, 'Brown Bread / Salad / Non-Veg', 'thursday_breakfast.jpg', '7:00 AM', '9:30 AM'),
(2, 'Turnip / Cucumber / Green', 'thursday_launch.jpg', '12:30 PM', '2:30 PM'),
(3, 'Tomato / Spices / Lemon', 'thursday_snacks.jpg', '5:00 PM', '6:30 PM'),
(4, 'Pasta / cheese / Paneer', 'thursday_dinner.jpg', '7:30 PM', '9:30 PM');

-- --------------------------------------------------------

--
-- Table structure for table `tuesday`
--

CREATE TABLE `tuesday` (
  `id` int(11) NOT NULL,
  `food` varchar(89) NOT NULL,
  `img` varchar(89) NOT NULL,
  `startTime` varchar(8) NOT NULL,
  `endTime` varchar(8) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tuesday`
--

INSERT INTO `tuesday` (`id`, `food`, `img`, `startTime`, `endTime`) VALUES
(1, 'Brown Bread / Salad / Non-Veg', 'tuesday_breakfast.jpg', '7:00 AM', '9:30 AM'),
(2, 'Turnip / Cucumber / Green', 'tuesday_launch.jpg', '12:30 PM', '2:30 PM'),
(3, 'Tomato / Spices / Lemon', 'tuesday_snacks.jpg', '5:00 PM', '6:30 PM'),
(4, 'Pasta / cheese / Paneer', 'tuesday_dinner.jpg', '7:30 PM', '9:30 PM');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `email` varchar(50) NOT NULL,
  `otp` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`email`, `otp`) VALUES
('jaydeep.ratanpara119430@marwadiuniversity.ac.in', 1),
('kencho.wangdi108140@marwadiuniversity.ac.in', 1),
('mohammadasif.raja108126@marwadiuniversity.ac.in', 1),
('niraj.giri108563@marwadiuniversity.ac.in', 1),
('sabij.soti107916@marwadiuniversity.ac.in', 1),
('sachin.sigdel108618@marwadiuniversity.ac.in', 1),
('sachit.upreti107914@marwadiuniversity.ac.in', 1),
('suman.jha108155@marwadiuniversity.ac.in', 1);

-- --------------------------------------------------------

--
-- Table structure for table `user_data`
--

CREATE TABLE `user_data` (
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `mealtime` text NOT NULL,
  `reason` longtext NOT NULL,
  `file` varchar(89) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user_data`
--

INSERT INTO `user_data` (`name`, `email`, `mealtime`, `reason`, `file`) VALUES
('', 'jaydeep.ratanpara119430@marwadiuniversity.ac.in', '', '', NULL),
('Kencho', 'kencho.wangdi108140@marwadiuniversity.ac.in', 'Lunch', 'Sick', '123.txt'),
('Niraj Giri', 'niraj.giri108563@marwadiuniversity.ac.in', 'Launch', 'Headache', '2022-11-111668184633.txt');

-- --------------------------------------------------------

--
-- Table structure for table `wednesday`
--

CREATE TABLE `wednesday` (
  `id` int(11) NOT NULL,
  `food` varchar(89) NOT NULL,
  `img` varchar(89) NOT NULL,
  `startTime` varchar(8) NOT NULL,
  `endTime` varchar(8) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `wednesday`
--

INSERT INTO `wednesday` (`id`, `food`, `img`, `startTime`, `endTime`) VALUES
(1, 'Brown Bread / Salad / Non-Veg', 'wednesday_breakfast.jpg', '7:00 AM', '9:30 AM'),
(2, 'Turnip / Cucumber / Green', 'wednesday_launch.jpg', '12:30 PM', '2:30 PM'),
(3, 'Tomato / Spices / Lemon', 'wednesday_snacks.jpg', '5:00 PM', '6:30 PM'),
(4, 'Pasta / cheese / Paneer', 'wednesday_dinner.jpg', '7:30 PM', '9:30 PM');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `chefs`
--
ALTER TABLE `chefs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `friday`
--
ALTER TABLE `friday`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `monday`
--
ALTER TABLE `monday`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `saturday`
--
ALTER TABLE `saturday`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `specialmenu`
--
ALTER TABLE `specialmenu`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sunday`
--
ALTER TABLE `sunday`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `thursday`
--
ALTER TABLE `thursday`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tuesday`
--
ALTER TABLE `tuesday`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`email`);

--
-- Indexes for table `user_data`
--
ALTER TABLE `user_data`
  ADD PRIMARY KEY (`email`);

--
-- Indexes for table `wednesday`
--
ALTER TABLE `wednesday`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `chefs`
--
ALTER TABLE `chefs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `friday`
--
ALTER TABLE `friday`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `monday`
--
ALTER TABLE `monday`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `saturday`
--
ALTER TABLE `saturday`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `specialmenu`
--
ALTER TABLE `specialmenu`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `sunday`
--
ALTER TABLE `sunday`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `thursday`
--
ALTER TABLE `thursday`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tuesday`
--
ALTER TABLE `tuesday`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `wednesday`
--
ALTER TABLE `wednesday`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
